from learningAlgortihms import *


def main():
    trainDataSet = readTrainData(trainDataPath)
    print("misclassification error (Linear) : ", kFoldCrossValidation(trainDataSet, 5, LinearModel()))
    print("misclassification error (Logistic): ", kFoldCrossValidation(trainDataSet, 5, LogisticModel()))


if __name__ == "__main__":
    main()
