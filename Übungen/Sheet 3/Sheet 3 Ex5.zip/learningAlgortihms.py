
import math
import random

import numpy as np
import pandas as pd

np.random.seed(1)
random.seed(1)

trainDataPath = "C:/Users/elias/PycharmProjects/MachineLearning/new_venv/data/sell-vs-not_balanced_train_data_handout.json"
testDataPath = "C:/Users/elias/PycharmProjects/MachineLearning/new_venv/data/sell-vs-not_balanced_test_data_handout.json"


def readTestData(path):
    data = pd.read_json(path)
    for col in data.columns[1:]:
        data[col] = meanNormalize(data[col].values)
    dataSet = []
    for index, row in data.iterrows():
        pageID = int(row[0])
        x = np.array([1] + row[1:])
        dataSet.append((pageID, x))
    return np.array(dataSet, dtype=object)


# (a)
def readTrainData(path):
    data = pd.read_json(path)
    for col in data.columns[5:]:
        data[col] = meanNormalize(data[col].values)
    dataSet = []
    for index, row in data.iterrows():
        # column 4 is the true classification, either "mainly" or "not"
        # column 5 and following contain the feature values
        c = 1 if row[4] == "mainly" else 0
        x = np.array([1] + row[5:])  # first value of feature vector x is always 1
        dataSet.append((x, c))
    return np.array(dataSet, dtype=object)


# (b)
def misclassification_rate(truth, predictions):
    """
    Given two one-dimensional arrays ‘truth‘ and ‘predictions‘
    of the same length, compute the misclassification rate.
    """
    if len(truth) != len(predictions):
        raise ValueError("Arrays must be of same length")
    sampleSize = len(truth)
    countClassifiedIncorrectly = len([i for i in range(sampleSize) if truth[i] != predictions[i]])
    return countClassifiedIncorrectly/sampleSize


# (c)
def meanNormalize(feature):
    """
    Calculate mean normalization for given list of feature values.
    @param feature: feature vector
    @type feature: np.ndarray
    @return: re-scaled values of the feauture vector
    @rtype: list
    """
    avg = feature.mean()
    r = feature.max() - feature.min()  # range
    return [(val-avg)/r for val in feature] if r > 0 else [0 for _ in feature]


# (d)
def leastMeanSquares(dataSet, alpha):
    """
    @param dataSet: Training examples of the form (x, c(x)), with |x| = p
    @type dataSet: list
    @param alpha: learning rate, a small positive constant
    @type alpha: float
    @return: weight vector with |w| = p + 1
    @rtype: numpy.array
    """
    # initialize random weights
    featureDimension = len(dataSet[0][0])
    w = np.random.uniform(low=-50, high=50, size=featureDimension).tolist()
    w = np.array(w)
    maxIter = 500
    i = 0
    while i < maxIter:
        (x, c) = random.choice(dataSet)
        y = np.dot(x, w)
        d = c - y
        dw = np.dot(alpha * d, x)
        w = w + dw
        i += 1
    return w


# (e)
def batchGradientDescent(dataSet, alpha):
    """
    @param dataSet: Training examples (x, c(x)) with |x| = p + 1, c(x) ∈ {0, 1}
    @type dataSet: list
    @param alpha: learning rate, a small positive constant
    @type alpha: float
    @return: weight vector with |w| = p + 1
    @rtype: numpy.array
    """
    # initialize random weights
    featureDimension = len(dataSet[0][0])
    w = np.random.uniform(low=0, high=100, size=featureDimension).tolist()
    w = np.array(w)
    maxIter = 500
    i = 0
    while i < maxIter:
        dw = 0
        for (x, c) in dataSet:
            y = sigmoid(np.dot(w, x))
            d = c - y
            dw += np.dot(alpha * d, x)
        w = np.add(w, dw)
        i += 1
    return w


# (f)
def kFoldCrossValidation(dataSet, k, model):
    """
    @param dataSet: Training examples  (x, c(x))
    @type dataSet: np.array
    @param k: the number of test sets
    @type k: int
    @param model: the model or hypothesis to be evaluated
    @type model: Model
    @return: Cross-Validation Error of y
    @rtype: float
    """
    testSets = splitDataSet(dataSet, k)
    errorSum = 0
    for testSet, trainingSet in testSets:
        model.train(trainingSet, alpha=0.01)
        errorSum += misclassification_rate([sample[1] for sample in testSet], [model.predict(sample[0]) for sample in testSet])
    return errorSum/k


class Model:
    def __init__(self):
        self.w = None

    def train(self, dataSet, alpha) -> np.array:
        pass

    def y(self, x) -> float:
        pass

    def predict(self, x) -> int:
        return 0 if self.y(x) < 0.5 else 1  # TODO swap?


class LinearModel(Model):
    def __init__(self):
        super().__init__()

    def train(self, dataSet, alpha):
        self.w = leastMeanSquares(dataSet, alpha)
        return self

    def y(self, x):
        return np.dot(self.w.T, x)


class LogisticModel(Model):
    def __init__(self):
        super().__init__()

    def train(self, dataSet, alpha):
        self.w = batchGradientDescent(dataSet, alpha)

    def y(self, x):
        return sigmoid(np.dot(self.w.T, x))


def sigmoid(x):
    return 1/(1 + math.exp(-x))



def splitDataSet(dataSet, k):
    """
    Splits given data set into k similar-sized disjoint subsets and returns array of tuples with subsets as first and
    respective complements as second entries. I.e., every entry is like (subset1, dataSet without subset1)
    @param k: # of subsets
    @type k: int
    @param dataSet: Set of examples
    @type dataSet: numpy.array
    @return: list of tuples
    @rtype: numpy.array
    """
    if len(dataSet) < k:
        raise ValueError("Dataset must at least have k entries")
    l = math.ceil(len(dataSet)/k)  # subset size
    result = []
    i = 1
    while True:
        if l * i >= len(dataSet):
            result.append((dataSet[:l*(i-1)], dataSet[l*(i-1):]))
            break
        result.append((dataSet[l*(i-1):(l*i)], np.concatenate((dataSet[:l*(i-1)], dataSet[l*i:]))))
        i += 1
    return result
